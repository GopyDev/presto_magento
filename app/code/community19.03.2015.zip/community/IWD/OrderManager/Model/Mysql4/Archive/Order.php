<?php
class IWD_OrderManager_Model_Mysql4_Archive_Order extends IWD_OrderManager_Model_Resource_Archive_Order_Collection
{

}

