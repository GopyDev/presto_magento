<?php
class Pulsestorm_Customerpage_Helper_Data extends Mage_Core_Helper_Abstract
{
}