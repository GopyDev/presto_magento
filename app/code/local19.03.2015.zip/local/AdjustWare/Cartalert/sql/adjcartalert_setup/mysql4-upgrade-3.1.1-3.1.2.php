<?php
/**
 * Abandoned Carts Alerts Pro
 *
 * @category:    AdjustWare
 * @package:     AdjustWare_Cartalert
 * @version      3.3.4
 * @license:     W22sKZAc65sLiShWmPFxsroCMZvSx8DyIvGLqZPs4w
 * @copyright:   Copyright (c) 2014 AITOC, Inc. (http://www.aitoc.com)
 */
$installer = $this;

$installer->startSetup();


$installer->run("

ALTER TABLE `".$installer->getTable('adjcartalert/cartalert')."` ADD `customer_group_id` INT(10) UNSIGNED DEFAULT NULL;

");

$installer->endSetup();