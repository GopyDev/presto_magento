<?php
class MQS_Newreport_Helper_Data extends Mage_Core_Helper_Abstract
{
  
}
