<?php

class Ajzele_CustomProduct_Model_Product_Type extends Mage_Catalog_Model_Product_Type_Abstract
{
	const TYPE_CP_PRODUCT = 'customproduct';
}