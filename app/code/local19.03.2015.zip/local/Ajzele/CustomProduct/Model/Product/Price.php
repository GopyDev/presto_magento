<?php

class Ajzele_CustomProduct_Model_Product_Price extends Mage_Catalog_Model_Product_Type_Price
{

}