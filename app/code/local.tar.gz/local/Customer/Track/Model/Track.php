<?php

class Customer_Track_Model_Track extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("track/track");

    }

}
	 