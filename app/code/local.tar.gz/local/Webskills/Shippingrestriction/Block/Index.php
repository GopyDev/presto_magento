<?php   
class Webskills_Shippingrestriction_Block_Index extends Mage_Core_Block_Template{   





}