<?php
    class Webskills_Shippingrestriction_Model_Mysql4_Shippingzip_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("shippingrestriction/shippingzip");
		}

		

    }
	 