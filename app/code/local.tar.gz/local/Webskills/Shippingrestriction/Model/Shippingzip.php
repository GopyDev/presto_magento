<?php

class Webskills_Shippingrestriction_Model_Shippingzip extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("shippingrestriction/shippingzip");

    }

}
	 