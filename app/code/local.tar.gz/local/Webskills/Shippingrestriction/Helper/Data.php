<?php
class Webskills_Shippingrestriction_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 