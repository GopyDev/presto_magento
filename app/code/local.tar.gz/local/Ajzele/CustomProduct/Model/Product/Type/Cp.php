<?php

/**
 * 
 * @author Branko Ajzele
 * 
 * Mage_Catalog_Model_Product_Type_Abstract
 * 
 * Mage_Catalog_Model_Product_Type_Simple
 * Mage_Catalog_Model_Product_Type_Virtual
 * Mage_Catalog_Model_Product_Type_Configurable
 * Mage_Catalog_Model_Product_Type_Grouped
 *
 */

class Ajzele_CustomProduct_Model_Product_Type_Cp extends Mage_Catalog_Model_Product_Type_Abstract
{

}